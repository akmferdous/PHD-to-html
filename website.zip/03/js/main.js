$(document).ready(function(){
	$('#bottom_header').meanmenu({
		meanMenuContainer: '#mobile_menu',
		meanScreenWidth: 991,
	});
});